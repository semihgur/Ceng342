/*
example include file
*/

void endOfTheProgram(void);
double ** randomMatrixCreator(int rows, int cols);
void matrixPrinter(double **matrix, int rows, int cols);