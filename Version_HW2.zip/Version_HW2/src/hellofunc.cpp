#include <stdio.h>
#include <hellomake.h>

void myPrintHelloMake(void) {

  printf("----------------------------------------------------\nProgram executed successfully!!\nCheck the bin folder for the output file.\n");

  return;
}